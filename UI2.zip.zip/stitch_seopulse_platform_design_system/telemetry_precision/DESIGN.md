---
name: Telemetry Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#59413e'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8d706d'
  outline-variant: '#e1bfbb'
  surface-tint: '#b02d29'
  primary: '#760009'
  on-primary: '#ffffff'
  primary-container: '#991b1b'
  on-primary-container: '#ffaaa1'
  inverse-primary: '#ffb4ac'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#00402b'
  on-tertiary: '#ffffff'
  tertiary-container: '#005a3d'
  on-tertiary-container: '#61d5a3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ac'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#8e1214'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.01em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style
The design system embodies analytical precision, institutional restraint, and clinical authority. Tailored for enterprise SEO professionals, search scientists, and performance engineers, the visual environment strips away ornamental SaaS bloat to favor intense information clarity, rapid pattern recognition, and calm executive decision-making.

The aesthetic merges **Minimalism** with **Modern Analytical Precision**:
- **Purity and Air:** Surfaces rely on layered off-whites, crisp hairline dividers, and deliberate whitespace rather than heavy fill boxes.
- **Controlled Urgency:** Instead of ubiquitous saturated tech blues, the primary signature is an authoritative deep crimson—evoking diagnostic telemetry, audit finality, and decisive editorial action.
- **Data Scannability:** Visual noise is actively suppressed. Visual weights are carried by typographic contrast, tabular metrics, and hairline structural borders, making anomalous crawl behaviors and algorithmic ranking shifts instantly identifiable.

## Colors
The color hierarchy is engineered to establish immediate hierarchy in dense tabular and graphical telemetry environments.

### Core Canvas & Neutrals
- **Canvas Base (`#FFFFFF`):** High-clarity primary workspace for data tables, analytical graphs, and cards.
- **Canvas Subdued (`#F8FAFC`):** Primary canvas wash, sub-panel backgrounds, and side navigation shells.
- **Canvas Muted (`#F1F5F9`):** Hover states, segmented control backdrops, and active table row indicators.
- **Border / Structural (`#E2E8F0`):** Hairline structure for card dividers, table grids, and input containers.
- **Text Primary (`#0F172A`):** Ultra-dark slate charcoal for absolute typographic clarity across headlines and raw values.
- **Text Secondary (`#334155`):** Muted slate for column headers, secondary descriptors, and labels.
- **Text Tertiary (`#64748B`):** Ghost text, timestamp watermarks, and inactive state cues.

### Brand & Semantic System
- **Primary Accent (`#991B1B`):** Deep carmine crimson. Used for the core brand mark, high-conviction callouts, primary interaction triggers, and active navigation nodes.
- **Status Critical (`#B91C1C`):** High-visibility red for crawl anomalies, canonical breaks, and indexation drop-offs.
- **Status Warning (`#D97706`):** Balanced warm amber for redirect loops, degraded Core Web Vitals, and soft 404 hazards.
- **Status Success (`#059669`):** Deep emerald for healthy crawls, green-tier lighthouse thresholds, and verified indexation.
- **Status Informational (`#0284C7`):** Precision sky slate for passive bots, structural discoveries, and indexing notes.

## Typography
Typographic discipline is central to this design system. It combines the sharp geometric grotesque personality of **Hanken Grotesk** for structured analytical narrative with the absolute computational clarity of **JetBrains Mono** for technical crawl data, HTTP codes, log dumps, and metrics.

- **Proportional Metrics:** Numerical telemetry, organic ranking deltas, keyword volume counts, and timestamps must always render via `label-mono` or `label-mono-sm` to ensure tabular alignment and immediate vertical glanceability.
- **Rhythm and Contrast:** Strict proportional line-heights prevent text-heavy dashboards from feeling congested. Display and headline levels leverage slight negative tracking to assert crisp authority without losing legibility.

## Layout & Spacing
The layout uses a 12-column fluid grid system pinned to an 8px base rhythm (with a 4px sub-grid for dense micro-components).

### Viewport Scaling
- **Desktop (1280px+):** 12-column layout with fixed 240px utility sidebar, `margin: 2rem`, and `gutter: 1.25rem`. Complex monitoring tables and multi-series telemetry charts operate full-width within the remaining canvas.
- **Tablet (768px - 1279px):** Sidebar collapses to an icon rail (64px). Grid adjusts to 8 columns with `margin: 1.5rem` and `gutter: 1rem`. Data grids introduce horizontal scrolling for granular metric columns.
- **Mobile (Below 768px):** 4-column layout with `margin-mobile: 1rem` and `gutter-mobile: 0.75rem`. Cards convert from multi-column grids to vertical stacks, and primary KPI metrics transition from multi-tile arrangements to swipable rails or stacked summaries.

## Elevation & Depth
This design system rejects heavy drop shadows, fuzzy skeuomorphic diffusions, and glossy blurs in favor of **Tonal Layers** and **Low-Contrast Outlines**. Depth is established strictly through surgical boundary lines and planar surface shifts:

- **Surface 0 (Page Canvas):** `#F8FAFC` provides the ambient structural shell.
- **Surface 1 (Cards, Modules, Tables):** `#FFFFFF` bordered with an unambiguous 1px solid `#E2E8F0`. No shadow is cast; the card is distinguished by the purity of its background against the base canvas.
- **Surface 2 (Flyouts, Menus, Popovers):** `#FFFFFF` with 1px solid `#CBD5E1` and an intentional, low-amplitude ambient shadow: `0 4px 16px -2px rgba(15, 23, 42, 0.06), 0 2px 4px -1px rgba(15, 23, 42, 0.04)`.
- **Active / Focused Interactive Planes:** Highlighted by replacing the border with the crimson primary token (`#991B1B`) or an auxiliary focus ring (`0 0 0 3px rgba(153, 27, 27, 0.12)`).

## Shapes
The shape language is strictly **Soft (Level 1)**. In an analytical application with hundreds of concurrent metrics on-screen, extreme border radii distort visual balance and consume valuable canvas density.

- **Base Components:** Inputs, buttons, segmented toggles, dropdowns, and data badges use `0.25rem` (4px).
- **Surface Containers (`rounded-lg`):** Dashboard metric cards, filter boards, and modal frames use `0.5rem` (8px).
- **Telemetry Pills:** Status indicators, micro health tags, and HTTP code badges maintain a structured, compact `0.25rem` corner rather than circular lozenges, sustaining a technical, instrument-like feel.

## Components

### Buttons
- **Primary:** Background `#991B1B`, text `#FFFFFF`, font-weight `500`. Hover state transitions to `#7F1D1D`. Focus ring `0 0 0 3px rgba(153, 27, 27, 0.2)`. Padding `0.5rem 1rem`.
- **Secondary / Outline:** Background `#FFFFFF`, border 1px solid `#E2E8F0`, text `#0F172A`. Hover transitions background to `#F8FAFC` and border to `#CBD5E1`.
- **Ghost:** Transparent background, text `#334155`. Hover transitions background to `#F1F5F9` and text to `#0F172A`.

### Status Badges & Chips
- Crisp, low-saturation pill boxes with 1px border.
- **Healthy / Indexed:** `#ECFDF5` background, `#059669` text, `#A7F3D0` border.
- **Warning / Degraded:** `#FFFBEB` background, `#D97706` text, `#FDE68A` border.
- **Critical / Dropped:** `#FEF2F2` background, `#B91C1C` text, `#FECACA` border.
- **Metric Badges:** `#F1F5F9` background, `#334155` text using `label-mono-sm` for response times, status codes (e.g., `200 OK`, `301`, `404`), and payload weights.

### Inputs & Filters
- Background `#FFFFFF`, 1px border `#E2E8F0`, border-radius `0.25rem`. Height fixed at 36px for high vertical density.
- Inner text uses `body-md` in `#0F172A` with placeholder text in `#94A3B8`.
- Focus state shifts border color to `#991B1B` with a 3px soft focus halo `rgba(153, 27, 27, 0.08)`.

### Checkboxes & Radio Buttons
- 16px square (or circle) with 1px border `#CBD5E1`.
- Selected state fills with `#991B1B` with a crisp `#FFFFFF` checkmark or center pin.

### Telemetry Cards
- Surface background `#FFFFFF`, border 1px solid `#E2E8F0`, border-radius `0.5rem`, padding `1.25rem`.
- Card headers strictly segregate title (`headline-sm`, `#0F172A`) from metadata action triggers using a bottom hairline border (`#F1F5F9`).

### Data Tables
- Header row uses `#F8FAFC` fill, `#475569` text, `0.75rem` vertical padding, with border-bottom 1px solid `#E2E8F0`. Column titles rendered in uppercase `label-mono` with muted sorting carats.
- Body rows feature clean `#FFFFFF` backgrounds, alternating optionally with `#FAFAFA` on dense sets; subtle hover highlight `#F8FAFC`.
- Cells containing raw URLs use single-line truncation with monospace styling.