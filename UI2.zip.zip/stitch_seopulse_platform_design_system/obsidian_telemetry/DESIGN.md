---
name: Obsidian Telemetry
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e4beb9'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ab8985'
  outline-variant: '#5b403d'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#b91c1c'
  on-primary-container: '#ffcdc7'
  inverse-primary: '#b91c1c'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#bec6e0'
  on-tertiary: '#283044'
  tertiary-container: '#565e74'
  on-tertiary-container: '#d0d8f2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  legal-clause:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.005em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: -0.02em
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  telemetry-metric:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-precision, technical aesthetic engineered for enterprise analytics, legal terms, security audits, and mission-critical SaaS governance. It balances the austere authority of a definitive legal document with the real-time velocity of telemetry monitoring. 

The visual voice is analytical, unembellished, and uncompromisingly direct. Rather than relying on decorative trends or skeuomorphic flourishes, it conveys credibility through micro-typography, surgical alignment, rigorous information architecture, and structured contrast. Every element serves an explicit analytical or transactional purpose. The emotional response is one of total reliability, institutional clarity, and computational rigor.

## Colors

The palette delivers intense functional clarity across both themes, anchoring primary brand and alert states in deep crimson (`#991b1b` and `#b91c1c`) balanced against obsidian foundations (`#09090b` and `#030712`) and slate gray intermediate structures.

### Theme Modes

#### Dark Mode (Default)
- **Canvas Base (`bg-canvas`):** `#09090b`
- **Surface Elevation 1 (`bg-surface-subtle`):** `#0f172a`
- **Surface Elevation 2 (`bg-surface-elevated`):** `#1e293b`
- **Border Structural (`border-default`):** `#334155` (reduced to `rgba(51, 65, 85, 0.4)` on low-emphasis separators)
- **Border Active / Contrast (`border-focus`):** `#64748b`
- **Text Primary (`text-main`):** `#f8fafc`
- **Text Secondary (`text-muted`):** `#94a3b8`
- **Text Subtle (`text-dim`):** `#64748b`
- **Accent Primary (`accent`):** `#b91c1c`
- **Accent Interactive Hover (`accent-hover`):** `#dc2626`
- **Accent Subdued (`accent-surface`):** `rgba(185, 28, 28, 0.12)`

#### Light Mode
- **Canvas Base (`bg-canvas`):** `#ffffff`
- **Surface Elevation 1 (`bg-surface-subtle`):** `#f8fafc`
- **Surface Elevation 2 (`bg-surface-elevated`):** `#f1f5f9`
- **Border Structural (`border-default`):** `#e2e8f0`
- **Border Active / Contrast (`border-focus`):** `#94a3b8`
- **Text Primary (`text-main`):** `#09090b`
- **Text Secondary (`text-muted`):** `#475569`
- **Text Subtle (`text-dim`):** `#64748b`
- **Accent Primary (`accent`):** `#991b1b`
- **Accent Interactive Hover (`accent-hover`):** `#7f1d1d`
- **Accent Subdued (`accent-surface`):** `rgba(153, 27, 27, 0.08)`

Crimson is reserved for structural telemetry triggers, critical validation thresholds, active navigation indicators, and executive calls to action. It must never be diluted with casual illustrations or non-essential graphics.

## Typography

Typography enforces hierarchical precision across high-density SaaS interfaces and long-form legal terms. 

- **Headlines (Hanken Grotesk):** Tight letter spacing, clean geometric terminations, and firm vertical proportions establish instant institutional authority without geometric coldness.
- **Body & Legal Documentation (Inter):** Highly legible across dense passages. Legal clauses run with expanded line heights (`lineHeight: 22px` on `13px` type) to preserve eye tracking across multi-page contract audits, terms of service, and compliance logs.
- **Telemetry & Metadata (JetBrains Mono):** Numbers, tags, timestamps, API headers, and telemetry readings strictly use monospace tabular figures (`font-variant-numeric: tabular-nums`). Monospace labels are set in uppercase with track-widening (`letterSpacing: 0.06em`) to serve as architectural anchor points.

## Layout & Spacing

The layout is constructed on an absolute 8-point base grid (subdivided to 4px for compact data tables and inputs).

### Grid Strategy
- **Application & Dashboard Screens:** 12-column fluid grid spanning full display width with persistent, collapsible navigation rails (64px icon state, 240px expanded state). Max fluid canvas width is bounded at `1600px` for ultra-wide displays to maintain metric readability.
- **Legal & Documentation Screens:** Asymmetrical 12-column layout. 3 columns dedicated to sticky jurisdictional/clause navigation index; 7 columns dedicated to legal copy (constrained to `68ch` line lengths for optical readability); 2 columns reserved for audit status, revision history, and export triggers.

### Breakpoints & Adaptations
- **Mobile (`< 640px`):** Canvas margin shifts to `1rem` (`margin-mobile`), 4-column layout, sticky clause tables compress into horizontal swipeable pill strips, telemetry dashboards stack vertically.
- **Tablet (`640px – 1024px`):** Canvas margin expands to `2rem`, 8-column layout, split panes collapse to master-detail modal views.
- **Desktop (`> 1024px`):** Full 12-column system, `3rem` section margins (`margin-desktop`), persistent dual-pane views for telemetry streams and concurrent audit trails.

## Elevation & Depth

Visual hierarchy does not use diffuse blurs or multi-color ambient drop shadows. Depth is achieved purely through **tonal stratification and razor-sharp border delineation**.

### Surface Strata
1. **Base Layer:** Pure Canvas (`#09090b` in Dark / `#ffffff` in Light). Unbordered root layer hosting background operations and main telemetry feeds.
2. **Structural Panels:** Sub-surface elements (`#0f172a` in Dark / `#f8fafc` in Light) bound by 1px solid hairline borders (`#334155` or `#e2e8f0`).
3. **Floating Overlays & Modals:** Elevated surfaces (`#1e293b` in Dark / `#f1f5f9` in Light) surrounded by dual-tone edge definition: an outer 1px structural stroke paired with a 1px inner inset highlight stroke (`rgba(255, 255, 255, 0.05)` in Dark / `rgba(0, 0, 0, 0.04)` in Light).

### Shadow Signature
Shadows are strictly confined to contextual menus, command bars (Cmd+K), and critical legal confirmation modals:
- `0 0 0 1px rgba(51, 65, 85, 0.8), 0 8px 24px -4px rgba(0, 0, 0, 0.6)` (Dark mode)
- `0 0 0 1px rgba(15, 23, 42, 0.08), 0 8px 24px -4px rgba(15, 23, 42, 0.12)` (Light mode)

## Shapes

The design system enforces a precision-tooled, architectural geometry with Level 1 (`Soft`) roundedness. 

- Standard interactive components (buttons, input fields, badges, telemetry cells) have `roundedness: 1` (`0.25rem` / `4px`). This maintains an intentional, mechanical rigor that mirrors terminal displays and printed contracts.
- Container panels, table shells, and card borders utilize `rounded-lg` (`0.5rem` / `8px`).
- Modals, large sheet panels, and system popovers utilize `rounded-xl` (`0.75rem` / `12px`).
- Fully rounded pills (`rounded-full`) are strictly prohibited, except for single-digit status count badges and live latency status pings.

## Components

### Buttons
- **Primary:** Solid crimson fill (`#b91c1c` Dark / `#991b1b` Light), stark white text, 4px corner radius, bold tabular text, active scale `0.98`. Focus ring: 2px offset crimson ring.
- **Secondary / Outline:** Transparent background, 1px border (`#334155` in Dark / `#cbd5e1` in Light), text matches secondary theme token. Hover introduces subtle slate fill (`#1e293b` in Dark / `#f1f5f9` in Light).
- **Destructive:** Transparent base with hairline crimson border, crimson text, transition to solid `#b91c1c` fill on hover.

### Inputs & Form Fields
- Fixed height of 36px for dense SaaS data capture.
- Hairline 1px border using `#334155` (Dark) or `#cbd5e1` (Light).
- Focus state instantly replaces border with high-contrast slate `#94a3b8` accompanied by 0px blur, 1px solid outer accent ring. No diffuse glows.
- Helper and validation messages render strictly in `label-mono` with matching icon markers.

### Telemetry Cards & Metric Panels
- Grid-bound containers featuring `label-mono` uppercase headers (e.g., `CRAWL_INDEX_RATE`, `HTTP_5XX_OCCURRENCE`).
- Large tabular numerals with subtle trend arrows (neutral slate for unchanged, vibrant crimson for critical degradation, emerald only for verified resolution).
- Top-right corner reserved for micro-pills containing machine-readable status (`LIVE`, `SYNCING`, `TERMINATED`).

### Legal Clause Panels & Indexing
- Numbered clause blocks (e.g., `§ 4.2.1 Limitation of Liability`) featuring persistent permalink anchor icons that illuminate on hover.
- Clause status chips: `AMENDED`, `DEPRECATED`, `BINDING`, set in uppercase `JetBrains Mono` at 10px with hairline border surrounds.
- Right-hand margin houses an interactive diff marker (green insertion line, crimson deletion line) for version history tracking.

### Checkboxes & Radios
- Sharp 2px corner radius for checkboxes; circular for radios.
- Unchecked: Inset border `#475569` with canvas background.
- Checked: Solid crimson background with pure white icon glyph.

### Status Indicators & Chips
- Monospace typographic tags with structural hairline borders (`border: 1px solid`).
- Subtle semi-transparent backgrounds (`rgba(185, 28, 28, 0.1)` for alert, `rgba(100, 116, 139, 0.1)` for neutral telemetry).
- Live pulse indicators: 6px circular dot with a continuous 1.5-second concentric radar ping animation.